var authHeaders = {
    serialNumber: 2,
    token: 0,
    instanceid: 0
};

var defaultData = {
    ONWEB: document.URL.indexOf('http://localhost') > -1 ? true : false,
    NAME: 'POLL',
    MODE: 'production',
    WIDGET_NAME: 'Quick Poll',
    BASE_URL: {
        dev: 'http://ec2-13-127-57-219.ap-south-1.compute.amazonaws.com:9999/genericservice/query/exec',
        preprod: 'https://betaexplore.rsocial.net:8104/genericservice/query/exec',
        production: 'https://pp.jiochat.com/genericservice/query/exec'
    },
    TYPE_INSERT: 'insert',
    TYPE_UPDATE: 'update',
    TYPE_SELECT: 'select',
    TYPE_SEND_MESSAGE: 'sendMessage',
    TABLE_DATA: 'miniapp.genericdatatable',
    TABLE_COUNTER: 'miniapp.genericcountertable',
    TIME: 'serverTime',
    CONFIG: 'config',
    RESPONSE: 'response',
    CONCAT_ITEM: '~@~',
    CONCAT_ITEM_VALUE: '=>',
    ARRAY_SPLIT: '][',
    ARRAY_SPLIT_ITEM: ',',
    REPLACE_ARRAY_SPLIT_ITEM:"~_~"

};

var APP = Object.freeze(defaultData);

var TABLE_MAPPING = {
    'instanceid': 'instanceid',
    'type': 'config',
    'miniapptype': 'appName',
    'stringcol1': 'question',
    'stringcol2': 'choices',
    'stringcol3': 'time',
    'stringcol4': 'visible',
    'stringcol5': 'image',
    'timestamp': 'serverTime'
};

var counterTableInsert = {
    "type": APP.TYPE_UPDATE,
    "table": APP.TABLE_COUNTER,
    "data": {
        "key": null,
        "counter": null
    }
};

var insertQueryData = {
    "type": APP.TYPE_INSERT,
    "table": APP.TABLE_DATA,
    "data": {
        "instanceid": 0,
        "type": APP.CONFIG,
        "miniapptype": APP.NAME,
        "stringcol1": 'Poll title',
        "stringcol2": [{
            name: "item1",
            status: false
        }, {
            name: "item2",
            status: false
        }],
        "stringcol3": 'Notes',
        "stringcol4": APP.WIDGET_NAME,
        "stringcol5": '',
        "timestamp": APP.TIME
    }
};

var sendMessageData = {
    input: {
        "type": APP.TYPE_SEND_MESSAGE,
        "update": false,
        "messageId": '',
        "instanceId": 0,
        "miniAppType": APP.NAME,
        "fields": []
    }
}

// Default data for generic counter table
var defaultCounterData = {
    "type": APP.TYPE_UPDATE,
    "table": APP.TABLE_COUNTER,
    "data": {
        "counter": 0,
    },
    "where": null
}

// Default data for generic data table
var defaultSelectData = {
    "table": APP.TABLE_DATA,
    "type": APP.TYPE_SELECT,
    "fields": Object.keys(TABLE_MAPPING),
    "where": null
};

var logData = [];

var logItem = {
    "type": 'API',
    "data": {},
    "status": true,
    "result": ''
};

let tempData = null;
var log = (result, type = 'API', data = {}, status = true) => {
    let lItem = clone(logItem);
    lItem.result = result;
    lItem.type = type;
    lItem.data = data;
    lItem.status = status;
    logData.push(lItem);
}

var getAllItemResponses = (instanceid, count, withRoot = true, isStringify = true) => {
    var counterTableQuery = clone(defaultSelectData);
    counterTableQuery.table = APP.TABLE_COUNTER;
    //counterTableQuery.whereIn = whereIn;
    if (count > 0) {
        let whereIn = "key in (";
        for (let i = 0; i < count; i++) {
            whereIn = whereIn +"'"+ instanceid + "_item_"+i+"',";
        }
        whereIn = whereIn.substring(0, whereIn.length - 1) + " )";
        counterTableQuery.whereIn = whereIn;
    }
    counterTableQuery.fields = ["key", "counter"];
    return makeSelectDataQuery(counterTableQuery, withRoot, isStringify);
}

// Function to fetch user response data from data table
var makeCardDataQuery = (instanceId, userId) => {

    let data = [];
    let selectQuery = clone(defaultSelectData);

    selectQuery.where = {
        instanceid: instanceId,
        type: "response",
        stringcol1: userId
    };
    let query1 = makeSelectDataQuery(selectQuery, false, false);

    data.push(query1);

    let query = {
        input: jsonString(data)
    }

    return jsonString(query);
}

var makeSendMessageQuery = (instanceid, messageId, isUpdate = false, count = 0) => {
    let data = [];
    //DataTable
    let dataTableQuery = clone(defaultSelectData);
    dataTableQuery.where = {
        instanceid: instanceid,
        type: APP.CONFIG
    };

    let dataTableSelectQuery = makeSelectDataQuery(dataTableQuery, false, false);

    data.push(dataTableSelectQuery);

    data.push(getAllItemResponses(instanceid, count, false, false));

    let query = sendMessageQueryBulder(instanceid, messageId, isUpdate, data);

    return query;
}

var sendMessageQueryBulder = (instanceid, messageId, isUpdate = false, data = []) => {
    let sendMessageQuery = clone(sendMessageData);
    sendMessageQuery.input.fields = data;
    //@TODO change it to boolean data.
    sendMessageQuery.input.update = isUpdate;
    sendMessageQuery.input.messageId = messageId;
    sendMessageQuery.input.instanceId = instanceid;
    let queryData = {
        input: jsonString([sendMessageQuery.input])
    }
    return queryData;
}

var makeSelectDataQuery = (data = {}, withRoot = true, isStringify = true) => {
    let selectQuery = null;
    if (isEmptyObject(data)) {
        selectQuery = clone(defaultSelectData);
        return selectQueryBuilder(selectQuery, withRoot, isStringify);
    } else {
        selectQuery = clone(data);
        if (!isEmptyObject(data.where)) {
            let whereClouse = "";
            for (let key in data.where) {
                if (isEmpty(whereClouse)) {
                    if (key === 'instanceid') {
                        whereClouse = key+"="+data.where[key];
                    } else {
                        whereClouse = key+"='"+data.where[key]+"'";
                    }
                } else {
                    if (key === 'instanceid') {
                        whereClouse = whereClouse+" and "+ key+"="+data.where[key];
                    } else {
                        whereClouse = whereClouse+" and "+ key+"='"+data.where[key]+"'";
                    }
                }
            }
            selectQuery.where = whereClouse;
        }
        if (data.whereIn) {
            selectQuery.where = data.whereIn;
            delete selectQuery.whereIn;
        }

    }
    return selectQueryBuilder(selectQuery, withRoot, isStringify);
}

var selectQueryBuilder = (selectData = defaultSelectData, withRoot = true, isStringify = true) => {
    let returnData = clone(selectData);
    if (!returnData.where) {
        delete returnData.where;
    }
    let data = null;
    if (withRoot) {
        data = {
            input: isStringify ? jsonString([returnData]) : returnData
        }
    } else {
        data = isStringify ? jsonString(returnData) : returnData
    }
    return data;
}

// Function that generates the query for inserting a row
var insertQueryBuilder = (queryData = insertQueryData, withRoot = true) => {

    let query = {
        type: queryData.type,
        table: queryData.table
    };

    if(queryData.type == 'update' && queryData.table == defaultData.TABLE_COUNTER) {
      query.tableType = 'counter';
    }

    if (queryData.where) {
        query.where = queryData.where;
    }
    let colFieldsValues = getFieldValue(queryData.data);
    let returnValue = null;
    if (withRoot) {
        returnValue = {
            input: jsonString([clone(query, colFieldsValues)])
        }
    } else {
        returnValue = clone(query, colFieldsValues);
    }
    return returnValue;
}

var updateCounter = (key, counter = 0, withRoot = false) => {
    let counterData = clone(defaultCounterData);
    counterData.data = {
        "counter": counter
    }
    counterData.where = "key='"+key+"'";
    let counterInsertQuery = insertQueryBuilder(counterData, withRoot);
    return counterInsertQuery;
}

var getFieldValue = (data) => {
    let returnValue = {
        fields: [],
        values: []
    }
    for (let key in data) {
        returnValue.fields.push(key);
        returnValue.values.push(data[key]);
    }
    return returnValue;
}

var callAPI = (data, headers = authHeaders, url = APP.BASE_URL[APP.MODE], type = 'POST', dataType = 'json', contentType = 'application/json') => {
    return $.ajax({
        type: type,
        url: url,
        headers: headers,
        data: data,
        dataType: dataType,
        contentType: contentType,
        beforeSend: function() { $.showPreloader("Loading...."); },
        complete: function() { $.hidePreloader(); },
    });
};



var commonAjaxUtility = (data, headers = authHeaders) => {
    return new Promise(function(resolve, reject) {
        if (isOnline()) {
            callAPI(data, headers).then(function(result) {
                log(result, 'API', data, true);
                resolve(result);
            }, function(error) {
                log(error, 'API', data, false);
                if (error.status == 428) {
                    tempData = null;
                    tempData = {
                        data: data,
                        headers: headers
                    };
                    sendToNative("getAuthToken", "handleAuthTokenOnAuthFail", "1");
                } else {
                    reject(error);
                }
            });
        } else {
            $.alert("", "No internet connection", function () {
                sendToNative("closeFullPage", null, null);
            });
        }
    });
}

function handleAuthTokenOnAuthFail(res) {
    try {
        var data = Base64.decode(res);
        tempData.headers.token = data;
        commonAjaxUtility(tempData.data, tempData.headers);
    } catch (e) {
        showAlert("handleAuthToken" + e);
    }
}
