let CONFIG_DATA = {
    messageId: UUID.randomUUIDHex(),
    instanceId: null,
    headerData: clone(authHeaders),
    cephBaseURL: null,
    clusterCode: null,
    containerFrom: null,
    containerTo: null,
    CEPHAuthHeadersData: null
}

$(document).ready(function() {
  onConfigurePageLoad();
});

function onConfigurePageLoad() {
    try {
        // Check if user is online
        if (isOnline()) {

            // Add android or ios class to body and accordingly change the styles
            setDeviceRelatedCss();

            // Check if params are present in the query and show the screen accordingly
            readDataFromConfigureURL();
        } else {
            internetConnectionError();
        }
    } catch (e) {
        showAlert("onConfigurePageLoad " + e);
    }
}

function readDataFromConfigureURL() {
    try {
        const urlData = getUrlParamsInJson(window.location.search);
        const instanceIdUrl = urlData['instanceId'];
        const isRespondPage = urlData['userRespond'];
        CONFIG_DATA.instanceId = parseInt(instanceIdUrl);

        if (isRespondPage && isRespondPage === "true") {
            const messageid = urlData['messageid'];
            CONFIG_DATA.messageId = messageid;
            CONFIG_DATA.isRespondPage = true;
            CONFIG_DATA.currentUserId = urlData['userId'];

            // For respond
            $("#respond-wrapper").show();
            $("#header-name").text('Poll');

            if (APP.ONWEB && APP.MODE !== "production") {
                getPrevItemData();
            }
            callRequiredNativeFunctions();

        } else {
            $("#create-wrapper").show();
            $("#header-name").text('Quick Poll');
            addChoice(1);
            addChoice(2);
            $('#pollEndDateTimePicker').val(moment().add(1,'day').format('YYYY-MM-DDTHH:mm'));
            callRequiredNativeFunctions();
        }

    } catch (e) {
        showAlert("readDataFromConfigureURL" + e);
    }
}

function callRequiredNativeFunctions() {
    try {
        sendToNative("getAuthToken", "handleAuthToken", "1");

        // The below calls are required for image upload purposes
        sendToNative("getCEPHHeader", "handleCEPHAuthHeaders", null);
        sendToNative("getCEPHDetails", "handleCEPHDetails", null);
    } catch (e) {
        showAlert("callRequiredNativeFunctions" + e);
    }
}

/*================ callback from native returning CEPH headers ================*/

function handleCEPHAuthHeaders(res) {
    try {
        var data = Base64.decode(res);
        CONFIG_DATA.CEPHAuthHeadersData = JSON.parse(data);
    } catch (e) {
        alert("handleCEPHAuthHeaders" + e);
    }
}


/**********************
 handle CEPH details
 This is required for posting and fetching images
**********************/

function handleCEPHDetails(base64CEPHDetail) {
    try {
        var decryptedCEPHDetail = JSON.parse(Base64.decode(base64CEPHDetail));
        CONFIG_DATA.cephBaseURL = decryptedCEPHDetail.baseURL;
        CONFIG_DATA.clusterCode = decryptedCEPHDetail.clusterCode;
        CONFIG_DATA.containerFrom = parseInt(decryptedCEPHDetail.containerFrom);
        CONFIG_DATA.containerTo = parseInt(decryptedCEPHDetail.containerTo);
    } catch (e) {
        alert("handleCEPHDetails" + e);
    }
}

function handleAuthToken(res) {
    try {
        const data = Base64.decode(res);
        CONFIG_DATA.headerData.token = data;

        // If user id is not available, fetch it
        if(!CONFIG_DATA.currentUserId) {
            sendToNative('getUserId', 'handleUserId', null);
        }
        sendToNative("getEncryptedValue", 'setInstanceId', CONFIG_DATA.instanceId.toString());
    } catch (e) {
        showAlert("handleAuthToken" + e);
    }
}

function handleUserId(res) {
    if (res) {
        try {
            const data = Base64.decode(res);
            CONFIG_DATA.currentUserId = data;
            log(data, "handleUserId");
        } catch (e) {
            showAlert("handleUserId" + e);
        }
    }
}

function setInstanceId(res){
    try {
        if (res) {
            CONFIG_DATA.headerData.instanceid = res;
            if (CONFIG_DATA.isRespondPage) {
                getPrevItemData();
            }
        } else {
            showAlert("setInstanceId error" + res);
        }
    } catch (e) {
        showAlert("setInstanceId API error" + e);
    }
}


// Function to fetch the choices created for the poll
function getItemData() {
    const itemsData = [];
    let index = 0;

    $('.item-container-div').each(function() {
        let itemValue = $(this).find('.enter-text-div').val().trim();
        if (itemValue) {
            itemValue = encodeURI(itemValue.replace(APP.ARRAY_SPLIT_ITEM, APP.REPLACE_ARRAY_SPLIT_ITEM));
            const itemString = `${index}${APP.CONCAT_ITEM_VALUE}${itemValue}`;
            itemsData.push(itemString);
            index++;
        }
    });

    return (itemsData.length > 1) ? itemsData : false;
}

// Function that gets executed on click on create poll
function createPollButtonClick() {

    // If not on production, bypass calls to native
    if (APP.ONWEB && APP.MODE !== "production") {
        addPoll();
    } else {
        const jsonToSend = JSON.stringify({               
            "instanceId" : CONFIG_DATA.instanceId,
            "needNotification" : false,
            "notificationMessage": false,
            "miniAppName": "Poll"
        });
        sendToNative("instanceConfirmationSuccess", "handleInstanceConfirmation", jsonToSend);
    }
}

function handleInstanceConfirmation(res) {
    if (res) {
        try {
            const result = Base64.decode(res);
            if (result == "true") {
                addPoll();
            } else {
                showAlert("Network error");
            }
        } catch (e) {
            showAlert("handleInstanceConfirmation" + e);
        }
    } else {
        showAlert("handleInstanceConfirmation failed");
    }
}

// Function to add poll
function addPoll() {

    if(!isOnline()) {
      internetConnectionError();
      return;
    }

    let errorMsg = '';

    const title = $("#titleTextDiv").val().trim();
    const itemData = getItemData();
    const endDateTime = $('#pollEndDateTimePicker').val().trim();
    const checkboxOptions = '' + $('#responseVisibleCheckbox').is(':checked') + ';' + $('#cannotChangeVoteCheckbox').is(':checked');

    // Poll question cannot be empty
    if (!title) {
        errorMsg += 'Please enter the poll question<br>';
    }

    // Poll choice cannot be empty
    if(!itemData) {
        errorMsg += 'Poll choice cannot be empty<br>';
    }

    // Poll end date cannot be empty
    if(!endDateTime) {
      errorMsg += 'Please choose a valid end time<br>';
    }

    // Check if there is image DATA
    if(imageData.length > 0) {
      if(imageData.length !== itemData.length || imageData.includes(undefined)) {
        errorMsg += 'Please select an image for the option<br>';
      }
    }

    // Get the end time in milliseconds
    const timeString = moment(endDateTime).valueOf() + '';

    // Poll end time cannot be of past
    if(parseInt(timeString) < Date.now()) {
      errorMsg += 'End time of poll cannot be of past';
    }

    // If no error, please proceed in creating a poll
    if (isEmpty(errorMsg) && CONFIG_DATA.instanceId) {

        let sendData = clone(insertQueryData);

        // Add image upload promises here, once all the images are uploaded
        // fetch their URLs and insert it in stringcol5
        if(imageData.length > 0) {
          var promises = [];
          const ceph_url = CONFIG_DATA.cephBaseURL.replace('/swift/v1', '/mappswift/swift/v1');
          let conNo, fullFileName, fileIds = [];

          for (var i = 0; i < imageData.length; i++) {
            conNo = getRandomInt(CONFIG_DATA.containerFrom, CONFIG_DATA.containerTo);
            fileIds[i] = generateFileName(ceph_url, conNo);
            fullFileName = "" + ceph_url + "" + CONFIG_DATA.clusterCode + "" + conNo + "/" + fileIds[i];
            promises.push(uploadFileOnCEPH(imageData[i], fullFileName, CONFIG_DATA.CEPHAuthHeadersData));
          }

          // The below gets resolved when all the promises resolves. Even if one fails, reject gets executed
          Promise.all(promises).then(res => {

              let items = [];
              res.map((item, index) => {
                if(item.status === 201) {
                items.push(fileIds[index]);
              } else {
                throw 'Something went wrong';
              }
              });

              sendData.data.stringcol5 = items.join(';');

              processPoll(sendData, title, itemData, timeString, checkboxOptions);

          }).catch((error) => {
            // Show the error message to the user
            $.alert("", errorMsg ? errorMsg : 'Something went wrong. Please retry');
          });
        } else {
          processPoll(sendData, title, itemData, timeString, checkboxOptions);
        }
    } else {
        // Show the error message to the user
        $.alert("", errorMsg ? errorMsg : 'Something went wrong');
    }
}

// This function gets called after images have been successfully uploaded or if there are no images, it gets called directly
function processPoll(sendData, title, itemData, timeString, checkBoxOptions) {
  // Instance id of this poll
  sendData.data.instanceid = CONFIG_DATA.instanceId;

  // Poll question
  sendData.data.stringcol1 = title;

  // Poll choices
  sendData.data.stringcol2 = itemData.join(APP.CONCAT_ITEM);

  // End time of poll
  sendData.data.stringcol3 = timeString;

  // Poll options: Response visible + user can update their choice
  sendData.data.stringcol4 = checkBoxOptions;

  // Image URLs
  sendData.data.stringcol5 = sendData.data.stringcol5 ? sendData.data.stringcol5 : '';

  // Current time
  sendData.data.timestamp = new Date();

  // Create data table query for inserting the poll
  const insertDataTableQuery = insertQueryBuilder(sendData, false);

  // Merge the two queries so that they can be executed on one go
  const insertQuery = {
      input: jsonString([insertDataTableQuery])
  }

  log(insertQuery, 'insertQuery');

  // AJAX call to insert instance in data table and counter table
  commonAjaxUtility(jsonString(insertQuery), CONFIG_DATA.headerData).then((insertQueryResult) => {

      log(insertQueryResult, 'insertQueryResult');

      // This AJAX call is to send message to other clients
      commonAjaxUtility(jsonString(makeSendMessageQuery(CONFIG_DATA.instanceId, CONFIG_DATA.messageId, false, itemData.length)), CONFIG_DATA.headerData).then((makeSendMessageResult) => {
          log(makeSendMessageResult, 'makeSendMessageResult');
          //@POPUP
          //showAlert(makeSendMessageResult);
          $.alert("", "Poll saved successfully", function () {
              sendToNative("closeFullPage", null, null);
          });

      }, (makeSendMessageError) => {

          log(makeSendMessageError, 'makeSendMessageError');
          //@POPUP
          if (makeSendMessageError.status === 200) {
              showAlert("Poll saved successfully");
              sendToNative("closeFullPage", null, null);
          }
      });
  }, (insertQueryError) => {
      log(insertQueryError, 'insertQueryError');
      //@POPUP
      showAlert(insertQueryError);
  });
}

// Function to generate the file name of the image
function generateFileName(ceph_url, conNo) {

  const dateTimeStamp = Math.round(new Date().getTime() / 1000);

  const eightDigitCode = randomString(8, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');

  return "CEPH-" + CONFIG_DATA.clusterCode + "" + conNo + "-" + eightDigitCode + "" + CONFIG_DATA.instanceId + "" + dateTimeStamp;
}

// Function to get the users response if any and also fetch the instances config data in order to display it
function getPrevItemData() {

    // This AJAX call is to fetch the instance's response data of user from data table if any
    commonAjaxUtility(makeCardDataQuery(CONFIG_DATA.instanceId, CONFIG_DATA.currentUserId), CONFIG_DATA.headerData).then((userData) => {

        if (userData.result && userData.result[0] && userData.result[0][0] && !isEmpty(userData.result[0][0].stringcol4)) {
            CONFIG_DATA.userResponse = userData.result[0][0];
            CONFIG_DATA.userRespondData = splitItemData(CONFIG_DATA.userResponse.stringcol4);
        }

        // Construct the query for fetching instance's config data
        const query = Object.assign({}, defaultSelectData);
        query.where = {
            instanceid: CONFIG_DATA.instanceId,
            type: 'config'
        };
        const selectQuery = JSON.stringify(makeSelectDataQuery(query));

        // This AJAX call is to fetch the instance's config data
        commonAjaxUtility(selectQuery, CONFIG_DATA.headerData).then((selectQueryResult) => {

            if (selectQueryResult.result && selectQueryResult.result[0] && selectQueryResult.result[0][0]) {

                CONFIG_DATA.configData = selectQueryResult.result[0][0];

                // Converts the string of poll choices back into json
                CONFIG_DATA.configDataItem = splitItemData(CONFIG_DATA.configData.stringcol2);

                // Convert images to fileID
                CONFIG_DATA.imageFileIds = (CONFIG_DATA.configData.stringcol5 && CONFIG_DATA.configData.stringcol5.trim() !== '') ? CONFIG_DATA.configData.stringcol5.trim().split(';') : [];

                if(CONFIG_DATA.imageFileIds.length > 0) {
                  // Fetch the image based on the file IDs
                  var ceph_url = CONFIG_DATA.cephBaseURL,
                  promises = [],
                  clusterCode,
                  fullFileURL, imageData = [];

                  for(let i = 0;i < CONFIG_DATA.imageFileIds.length;i++) {
                    clusterCode = CONFIG_DATA.imageFileIds[i].split('-')[1];
                    fullFileURL = (`${ceph_url}${clusterCode}/${CONFIG_DATA.imageFileIds[i]}`).trim();
                    promises.push(fetchFileFromCEPH(fullFileURL, CONFIG_DATA.CEPHAuthHeadersData));
                  }

                  Promise.all(promises).then((res) => {
                    var promises2 = [];
                    res.map((item) => {
                      if(item.status == 200) {
                        promises2.push(item.text());
                      } else {
                        imageData = [];
                        throw 'Something went wrong';
                      }
                    });

                    return Promise.all(promises2);

                  }).then(datas => {
                    imageData = [];
                    datas.map((data) => {
                      imageData.push(data);
                    });
                    renderImages(imageData);

                  }).catch(error => {
                    console.log(error);
                  });
                }
                // Show the poll question
                $("#respond-title").text(CONFIG_DATA.configData.stringcol1);
            }

            // Show the poll choices and if user responded, show it as marked
            showList();
        }, (selectQueryError) => {
            //error
            log(selectQueryError, "selectQueryError");
        });

    }, (userDtaError) => {
        log(userDtaError, 'userDtaError');
    });
}

// Function to render the poll images
function renderImages(imageData) {
  var pollImages = $('.poll-image');
  for (let i = 0;i < pollImages.length;i++) {
    $(pollImages[i]).css({'background-image':`url(${imageData[i]})`,'width': '3.5rem','height': '3.5rem', 'min-width': '3.5rem'});
  }
}

// Function to show the list of poll choices on vote now screen
function showList() {

    const data = clone(CONFIG_DATA.configDataItem);

    const alreadyChecked = [];

    let listHtml = '';

    for (let key in data) {
        let checked = '';
        if (CONFIG_DATA.userRespondData) {
            if (CONFIG_DATA.userRespondData[key] && CONFIG_DATA.userRespondData[key] === "true") {
                checked = "checked";
                alreadyChecked.push(key);
            }
        }
        listHtml = `${listHtml} <div class="col-xs-12 common-padding item-container-div">
                      <div class="common-text-div margin-text-div pull-left" style="width:100%">
                        <label for="key_${key}" style="padding-left: 13px; padding-top: 4px;display: block;width: 100%">
                          <div class="row" style="width:100%;margin: 0 auto;border-bottom: 1px solid darkgray">
                          <div class="col-xs-10 poll-choice">
                            <div class="poll-image"></div>
                            <div>${data[key]}</div>
                          </div>
                          <div class="col-xs-2"><input value="${key}" name="pollChoice" id="key_${key}" type="radio" class="check-box-div" ${checked}/></div>
                          </div>
                        </label>
                        </div>
                    </div>`;
    }

    CONFIG_DATA.alreadyChecked = alreadyChecked;

    $("#respond-multipleItemContainer").html(listHtml);
}


// Function that fetches the option selected by user and if already checked, decrements counter by 1 else update by 1
function getRespondedItemData() {

    const itemsData = [];
    const checkData = [];

    $('#respond-multipleItemContainer .item-container-div').each(function() {
        const itemsChecked = $(this).find(".check-box-div").is(":checked");
        const itemValue = $(this).find(".check-box-div").prop('value');

        if (itemsChecked === true && CONFIG_DATA.alreadyChecked.indexOf(itemValue) === -1) {
            checkData.push(updateCounter(`${CONFIG_DATA.instanceId}_item_${itemValue}`, '+1'));
        }

        if (itemsChecked !== true && CONFIG_DATA.alreadyChecked.indexOf(itemValue) >= 0) {
            checkData.push(updateCounter(`${CONFIG_DATA.instanceId}_item_${itemValue}`, '-1'));
        }

        const itemString = `${itemValue}${APP.CONCAT_ITEM_VALUE}${itemsChecked}`;
        itemsData.push(itemString);
    });

    CONFIG_DATA.queryArray = checkData;

    return itemsData;
}

// Function that gets executed on click of vote now
function respondPollButtonClick() {

    CONFIG_DATA.queryArray = null;

    // Function that updates the query in case user has already responded and fetches users response
    const itemData = getRespondedItemData();

    const choiceIndex = setChoiceIndex(itemData);

    // If no choice is selected, throw an error
    if(choiceIndex === null) {
      $.alert("", "Please select an option");
      return false;
    }

    let sendData = clone(insertQueryData);

    sendData.data = {
        "type": 'response',
        "instanceid": CONFIG_DATA.instanceId,
        "stringcol1": `${CONFIG_DATA.currentUserId}`,
        "stringcol2": " ",
        "stringcol3": " ",
        "stringcol4": itemData.join(APP.CONCAT_ITEM),
        "timestamp": new Date()
    }
    sendData.where = `instanceid=${CONFIG_DATA.instanceId} and type='response' and stringcol1='${CONFIG_DATA.currentUserId}'`;


    const insertDataTableQuery = insertQueryBuilder(sendData, false);

    // If user has not responded before, increment counter by 1, else getRespondedItemData takes care of it
    if (!CONFIG_DATA.userRespondData) {
        const counterInsertQuery = updateCounter(`${CONFIG_DATA.instanceId}_response`, 1);
        CONFIG_DATA.queryArray.push(counterInsertQuery);
    }

    CONFIG_DATA.queryArray.push(insertDataTableQuery);

    const insertQuery = {
        input: jsonString(CONFIG_DATA.queryArray)
    }

    log(insertQuery, 'insertQuery');

    // AJAX call to record user's response
    commonAjaxUtility(jsonString(insertQuery), CONFIG_DATA.headerData).then((updateQueryResult) => {

        // AJAX call to send message that will dispatch to all users.
        // MakeSendMessageQuery third param is true when existing card needs to be updated

        commonAjaxUtility(jsonString(makeSendMessageQuery(CONFIG_DATA.instanceId, CONFIG_DATA.messageId, true, Object.keys(CONFIG_DATA.configDataItem).length)), CONFIG_DATA.headerData).then((makeSendMessageResult) => {

            log(makeSendMessageResult, 'makeSendMessageResult');

            const timekey = `${CONFIG_DATA.instanceId}_time_${CONFIG_DATA.currentUserId}`;
            const choicekey = `${CONFIG_DATA.instanceId}_choice_${CONFIG_DATA.currentUserId}`;

            // This key is used to determine if user has already responded to the poll
            setLocal(timekey, new Date());

            // This key is to determine the choice marked by the user
            setLocal(choicekey, choiceIndex);


            $.alert("", "Response saved successfully", function () {
                //For dev only
                if (APP.ONWEB && APP.MODE !== "production") {
                    location = document.URL;
                }
                sendToNative("closeFullPage", null, null);
            });

        }, (makeSendMessageError) => {
            log(makeSendMessageError, 'makeSendMessageError');
            //Error
        });

    }, (updateQueryError) => {})

}

// Determine index of choice selected by user
function setChoiceIndex(items) {
  let index = null;
  items.forEach((item, i) => {
    if(item.split(APP.CONCAT_ITEM_VALUE)[1] == "true") {
      index = i;
    }
  });
  return index;
};

// If user clicks on back button, send message to native to close the web view
function moveToPreviousPage() {
    try {
        sendToNative("closeFullPage", null, null);
    } catch (e) {
        alert("moveToPreviousPage" + e);
    }
}

// Event to add a choice
$("#addItemDiv").click(function() {
  addChoice($('.deleteChoice').length + 1);
});

function addChoice(i) {
  const elementHtml = `
  <div class="item-container-div">
            <div class="col-xs-10 choice-input-div">
              <div class="hidden poll-image"></div>
              <input type="text" class="enter-text-div" placeholder="Choice ${i}" />
              <img src="assets/image/u322.png" class="image-placeholder" />
            </div>
            <div class="col-xs-2 common-padding deleteChoice">
              <i class="fa fa-times fa-2x"></i>
            </div></div>`;
  $("#multipleItemContainer").append(elementHtml);
}

//----------------------------------------------------------------------------//
// This section of code deals with handling on images for poll
var imageClicked, imageData = [];

// On click of empty image icon, open file select box
$(document).on('click', '.image-placeholder', function() {
  imageClicked = this;
  $('#imageSelector').trigger('click');
});

// On change of file input, trigger the handleFiles Input
function handleFiles(files) {
  if (files && files.length > 0) {
    try {
      var file = new FileReader();
      file.onload = function (data) {
        if (data) {
          imageData[$(imageClicked).closest('.item-container-div').index()] = data.target.result;
          $($(imageClicked).siblings('.poll-image')[0]).css({'background-image': `url(${data.target.result})`, 'width': '3.5rem', 'height': '3.5rem', 'min-width': '3.5rem'}).removeClass('hidden');
          $('#imageSelector').val("");
        }
      }
      file.readAsDataURL(files[0]);
    } catch (e) {
      alert("handleFiles" + e);
    }
  }
}

//----------------------------------------------------------------------------//

// Event to delete choice
$(document).on('click touchend', '.deleteChoice', function() {
    if ($('.item-container-div').length > 2) {
      $(this).parent('.item-container-div').remove();
      imageData.splice($(this).closest('.item-container-div').index(), 1);
    } else {
      const index = $(this).closest('.item-container-div').index()
      $(this).siblings('.choice-input-div').find('.enter-text-div').val('');
      $($('.poll-image')[index]).addClass('hidden');
      imageData.splice(index,1);
    }
});

// Event to show image preview
$(document).on('click touchend', '.poll-image', function() {
  var image = $(this).css('background-image');
  $('#imagePreviewContainer').css({'background-image': image}).show();
});

// On click of image preview, close the preview container
$('#imagePreviewContainer').click(function() {
  $(this).hide();
});
