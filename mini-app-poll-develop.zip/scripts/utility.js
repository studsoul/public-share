

// Apply styles specific to android/ios
const setDeviceRelatedCss = () => {
  try {
    var currentDevice = getMobileOperatingSystem();
    var body = document.body;
    body.classList.add(currentDevice);
  } catch (e) {
    alert("setDeviceRelatedCss" + e);
  }
}

const isEmpty = (data) => {
  if (data && data.trim() !== '') {
    return false;
  }
  return true;
}

const isEmptyObject = (obj) => {
  return jQuery.isEmptyObject(obj);
}

const showAlert = (data) => {
  if (APP.MODE !== 'production') {
    if (typeof data === 'object') {
      alert(jsonString(data));
    } else {
      alert(data);
    }
  }
}

const alertMessgage = (text) =>{

};

const setLocal = (key, data) => {
  if (typeof data === 'object') {
    localStorage.setItem(key, JSON.stringify(data));
  } else {
    localStorage.setItem(key, data);
  }

}

const getLocal = (key, isObject = true) => {
  if (isObject) {
    return JSON.parse(localStorage.getItem(key) || '{}')
  } else {
    return localStorage.getItem(key) || null;
  }
}

const deleteLocal = (key) => {
  localStorage.removeItem(key);
}

const jsonString = (obj) => {
  return JSON.stringify(obj);
}

const clone = (obj, obj1 = {}) => {
  return Object.assign({}, obj, obj1);
}

const getUrlParamsInJson = (url) => {
  var arrayData = [];
  url.replace('?', '').split('&').map(function (values) {
    var urlData = values.split('=');
    arrayData[urlData[0]] = urlData[1];
  })
  return arrayData;
}

const isOnline = () => {
  if(window.navigator) {
    return navigator.onLine;
  }
  return true;
}

const removeHtml = (string) => {
  if (string) {
    return string.replace(/(<([^>]+)>)/ig, "");
  }
  return string;
}

const setText = (element, string) => {
  element.text(removeHtml(string));
}

const sanitizeText = (string) => {
  return removeHtml(string);
}


const getResultDataInJSON = (data, last = true, sendArray = true) => {
  if (data) {
    if (data.indexOf(APP.ARRAY_SPLIT) > -1) {
      return getMultipleArrayData(data, last);
    } else {
      return getSingleArrayData(data, sendArray);
    }
  }
  return {};
}


// Splits the string of poll choices into an array
const splitItemData = (data) => {
    //
  let returnData = {};
  if (data) {
    const items = data.split(APP.CONCAT_ITEM);
    items.map(function (item) {
      const itemData = item.split(APP.CONCAT_ITEM_VALUE);
      if (itemData.length === 2) {
        const key = itemData[0].trim();
        // const val = decodeURI(itemData[1].trim());
        const val = decodeURI(itemData[1].replace(APP.REPLACE_ARRAY_SPLIT_ITEM, APP.ARRAY_SPLIT_ITEM));
        returnData = clone(returnData, {
          [key]: val
        })
      }
    });
  }
  return returnData;
}

const getItemResponsed = (data) => {
  try {
    let count = 0;
    for (let key in data) {
      if (data[key] && data[key][1] && parseInt(data[key][1]) > 0) {
        count++;
      }
    }
    return count;
  } catch (e) {
    showAlert("getItemResponsed" + e)
  }
}

const findInJson = (data, searchtext) => {
  let result = {};
  data.find(item => {
    for (let key in item) {
      if (item[key] === searchtext) {
        result = item;
      }
    }
  });

  return result;
}


UUID.hexChar = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"];

UUID.randomUUIDHex = function () {
  var byteArray = UUID.randomUUID();
  var str = "";
  for (var index = 0; index < byteArray.length; index++) {
    var b = byteArray[index];
    var val = UUID.hexChar[(b >> 4) & 0x0f] + UUID.hexChar[b & 0x0f];
    str += val;
  }
  return str;
}

/*================== converting to required format ======================*/

function convertTimeToRequiredFormat(data) {
    try {
        var dt = moment(data, ["h:mm A"]).toDate();
        return dt;
    } catch (e) {
        alert("convertTimeToRequiredFormat" + e);
    }
}


// Fetch call to upload image on the server
function uploadFileOnCEPH(data, url, headers) {
  return fetch(url, {
    method: 'POST',
    body: data,
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'token': headers.token,
      'userid': headers.userid
    }
  });
}

// Fetch call to fetch image from the server
function fetchFileFromCEPH(url, headers) {
  return fetch(url, {
    method: 'GET',
    headers: new Headers({
      'token': headers.token,
      'userid': headers.userid
    })
  });
}

/*================ function for generating random integer =====================*/

function getRandomInt(min, max) {
    try {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min)) + min;
    } catch (e) {
        alert("getRandomInt" + e);
    }
}

/*================ function for generating eight digit code =====================*/

function randomString(length, chars) {
    try {
        var result = '';
        for (var i = length; i > 0; --i) {
            result += chars[Math.floor(Math.random() * chars.length)];
        }
        return result;
    } catch (e) {
        alert("randomString" + e);
    }
}
